﻿using System.Windows;

namespace DentalClinicWPF
{
    public partial class App : Application
    {
    }
}