﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using DentalClinicWPF.ViewModels.Patient.PatientDetail;
using DentalClinicWPF.Models;

namespace DentalClinicWPF.Views.Patient.PatientDetail
{
    public partial class PatientDetailView : UserControl
    {
        public PatientDetailView()
        {
            InitializeComponent();
        }
    }
}