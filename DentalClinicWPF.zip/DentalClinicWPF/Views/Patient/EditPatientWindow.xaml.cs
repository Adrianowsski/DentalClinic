﻿using System.Windows;

namespace DentalClinicWPF.Views.Patient
{
    public partial class EditPatientWindow : Window
    {
        public EditPatientWindow()
        {
            InitializeComponent();
        }
    }
}