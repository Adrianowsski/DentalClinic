﻿using System.Windows.Controls;

namespace DentalClinicWPF.Views.Supplier;

public partial class SupplierView : UserControl
{
    public SupplierView()
    {
        InitializeComponent();
    }
}