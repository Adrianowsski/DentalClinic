﻿using System.Windows;

namespace DentalClinicWPF.Views.Supplier;

public partial class EditSupplierView : Window
{
    public EditSupplierView()
    {
        InitializeComponent();
    }
}