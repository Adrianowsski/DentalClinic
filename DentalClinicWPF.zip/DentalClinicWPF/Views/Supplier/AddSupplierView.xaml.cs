﻿using System.Windows;

namespace DentalClinicWPF.Views.Supplier;

public partial class AddSupplierView : Window
{
    public AddSupplierView()
    {
        InitializeComponent();
    }
}