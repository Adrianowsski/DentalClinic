﻿using System.Windows.Controls;

namespace DentalClinicWPF.Views.Employee;

public partial class EmployeeView : UserControl
{
    public EmployeeView()
    {
        InitializeComponent();
    }
}