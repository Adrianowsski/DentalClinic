﻿using System.Windows;

namespace DentalClinicWPF.Views.Employee;

public partial class AddEmployeeView : Window
{
    public AddEmployeeView()
    {
        InitializeComponent();
    }
}