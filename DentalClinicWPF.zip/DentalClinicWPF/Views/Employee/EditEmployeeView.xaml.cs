﻿using System.Windows;

namespace DentalClinicWPF.Views.Employee;

public partial class EditEmployeeView : Window
{
    public EditEmployeeView()
    {
        InitializeComponent();
    }
}