﻿using System.Windows.Controls;

namespace DentalClinicWPF.Views.LabOrder;

public partial class LabOrderView : UserControl
{
    public LabOrderView()
    {
        InitializeComponent();
    }
}