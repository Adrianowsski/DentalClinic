﻿using System.Windows;

namespace DentalClinicWPF.Views.LabOrder;

public partial class AddLabOrderView : Window
{
    public AddLabOrderView()
    {
        InitializeComponent();
    }
}