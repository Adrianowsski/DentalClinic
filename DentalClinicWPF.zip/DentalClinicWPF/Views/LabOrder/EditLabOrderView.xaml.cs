﻿using System.Windows;

namespace DentalClinicWPF.Views.LabOrder;

public partial class EditLabOrderView : Window
{
    public EditLabOrderView()
    {
        InitializeComponent();
    }
}