﻿using System.Windows.Controls;

namespace DentalClinicWPF.Views.Treatment;

public partial class TreatmentView : UserControl
{
    public TreatmentView()
    {
        InitializeComponent();
    }
}