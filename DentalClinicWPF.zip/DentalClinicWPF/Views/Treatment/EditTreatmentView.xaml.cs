﻿using System.Windows;

namespace DentalClinicWPF.Views.Treatment;

public partial class EditTreatmentView : Window
{
    public EditTreatmentView()
    {
        InitializeComponent();
    }
}