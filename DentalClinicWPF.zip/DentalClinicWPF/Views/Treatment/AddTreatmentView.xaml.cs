﻿using System.Windows;

namespace DentalClinicWPF.Views.Treatment
{
    /// <summary>
    /// Interaction logic for AddEditTreatmentWindow.xaml
    /// </summary>
    public partial class AddEditTreatmentView : Window
    {
        public AddEditTreatmentView()
        {
            InitializeComponent();
        }
    }
}