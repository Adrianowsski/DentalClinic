﻿using System.Windows;

namespace DentalClinicWPF.Views.TreatmentPlan;

public partial class AddTreatmentPlanView : Window
{
    public AddTreatmentPlanView()
    {
        InitializeComponent();
    }
}