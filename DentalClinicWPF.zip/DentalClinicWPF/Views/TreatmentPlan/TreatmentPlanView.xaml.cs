﻿using System.Windows.Controls;

namespace DentalClinicWPF.Views.TreatmentPlan
{
    public partial class TreatmentPlanView : UserControl
    {
        public TreatmentPlanView()
        {
            InitializeComponent();
        }
    }
}