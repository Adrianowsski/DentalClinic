﻿using System.Windows;

namespace DentalClinicWPF.Views.TreatmentPlan;

public partial class EditTreatmentPlanView : Window
{
    public EditTreatmentPlanView()
    {
        InitializeComponent();
    }
}