﻿using System.Windows.Controls;

namespace DentalClinicWPF.Views.Appointment;

public partial class AppointmentView : UserControl
{
    public AppointmentView()
    {
        InitializeComponent();
    }
}