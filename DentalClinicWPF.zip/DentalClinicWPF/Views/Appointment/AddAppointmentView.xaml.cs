﻿using System.Windows;

namespace DentalClinicWPF.Views.Appointment
{
    public partial class AddAppointmentView : Window
    {
        public AddAppointmentView()
        {
            InitializeComponent();
        }
    }
}