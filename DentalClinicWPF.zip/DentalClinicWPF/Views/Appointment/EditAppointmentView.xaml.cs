﻿using System.Windows;

namespace DentalClinicWPF.Views.Appointment;

public partial class EditAppointmentView : Window
{
    public EditAppointmentView()
    {
        InitializeComponent();
    }
}