﻿using System.Windows;

namespace DentalClinicWPF.Views.MedicalRecord;

public partial class EditMedicalRecordView : Window
{
    public EditMedicalRecordView()
    {
        InitializeComponent();
    }
}