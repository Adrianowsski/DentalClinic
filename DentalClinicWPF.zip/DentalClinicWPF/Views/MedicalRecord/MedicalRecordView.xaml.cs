﻿using System.Windows.Controls;

namespace DentalClinicWPF.Views.MedicalRecord
{
    public partial class MedicalRecordView : UserControl
    {
        public MedicalRecordView()
        {
            InitializeComponent();
        }
    }
}