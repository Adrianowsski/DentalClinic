﻿using System.Windows;

namespace DentalClinicWPF.Views.MedicalRecord;

public partial class AddMedicalRecordView : Window
{
    public AddMedicalRecordView()
    {
        InitializeComponent();
    }
}