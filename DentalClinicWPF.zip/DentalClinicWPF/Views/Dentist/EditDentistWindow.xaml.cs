﻿using System.Windows;

namespace DentalClinicWPF.Views.Dentist;

public partial class EditDentistWindow : Window
{
    public EditDentistWindow()
    {
        InitializeComponent();
    }
}