﻿using System.Windows;

namespace DentalClinicWPF.Views.Dentist
{
    public partial class AddDentistWindow : Window
    {
        public AddDentistWindow()
        {
            InitializeComponent();
        }
    }
}