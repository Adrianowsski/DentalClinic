﻿using System.Windows.Controls;

namespace DentalClinicWPF.Views.Dashboard;

public partial class DashboardView : UserControl
{
    public DashboardView()
    {
        InitializeComponent();
    }
}