﻿using System.Windows.Controls;

namespace DentalClinicWPF.Views.Equipment
{
    public partial class EquipmentView : UserControl
    {
        public EquipmentView()
        {
            InitializeComponent();
        }
    }
}