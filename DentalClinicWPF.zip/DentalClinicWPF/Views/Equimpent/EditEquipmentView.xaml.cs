﻿using System.Windows;

namespace DentalClinicWPF.Views.Equipment
{
    public partial class EditEquipmentView : Window
    {
        public EditEquipmentView()
        {
            InitializeComponent();
        }
    }
}