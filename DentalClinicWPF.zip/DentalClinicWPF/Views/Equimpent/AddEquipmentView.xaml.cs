﻿using System.Windows;

namespace DentalClinicWPF.Views.Equipment
{
    public partial class AddEquipmentView : Window
    {
        public AddEquipmentView()
        {
            InitializeComponent();
        }
    }
}