﻿using System.Windows;

namespace DentalClinicWPF.Views.Invoice;

public partial class EditInvoiceView : Window
{
    public EditInvoiceView()
    {
        InitializeComponent();
    }
}