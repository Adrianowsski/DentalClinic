﻿using System.Windows;

namespace DentalClinicWPF.Views.Invoice;

public partial class AddInvoiceView : Window
{
    public AddInvoiceView()
    {
        InitializeComponent();
    }
}