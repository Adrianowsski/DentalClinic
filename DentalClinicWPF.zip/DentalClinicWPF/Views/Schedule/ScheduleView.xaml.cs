﻿using System.Windows.Controls;

namespace DentalClinicWPF.Views.Schedule;

public partial class ScheduleView : UserControl
{
    public ScheduleView()
    {
        InitializeComponent();
    }
}