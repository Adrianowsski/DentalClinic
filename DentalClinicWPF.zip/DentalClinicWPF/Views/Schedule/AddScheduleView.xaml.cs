﻿using System.Windows;

namespace DentalClinicWPF.Views.Schedule;

public partial class AddScheduleView : Window
{
    public AddScheduleView()
    {
        InitializeComponent();
    }
}