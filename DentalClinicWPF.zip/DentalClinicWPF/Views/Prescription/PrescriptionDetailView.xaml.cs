﻿using System.Windows.Controls;

namespace DentalClinicWPF.Views.Prescription
{
    public partial class PrescriptionDetailView : UserControl
    {
        public PrescriptionDetailView()
        {
            InitializeComponent();
        }
    }
}