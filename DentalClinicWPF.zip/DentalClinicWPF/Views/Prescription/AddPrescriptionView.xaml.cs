﻿using System.Windows;

namespace DentalClinicWPF.Views.Prescription;

public partial class AddPrescriptionView : Window
{
    public AddPrescriptionView()
    {
        InitializeComponent();
    }
}