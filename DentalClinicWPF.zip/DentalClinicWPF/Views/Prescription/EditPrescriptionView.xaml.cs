﻿using System.Windows;

namespace DentalClinicWPF.Views.Prescription;

public partial class EditPrescriptionView : Window
{
    public EditPrescriptionView()
    {
        InitializeComponent();
    }
}