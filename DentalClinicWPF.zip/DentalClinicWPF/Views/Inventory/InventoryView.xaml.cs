﻿using System.Windows.Controls;

namespace DentalClinicWPF.Views.Inventory;

public partial class InventoryView : UserControl
{
    public InventoryView()
    {
        InitializeComponent();
    }
}