﻿using System.Windows;

namespace DentalClinicWPF.Views.Inventory;

public partial class EditInventoryView : Window
{
    public EditInventoryView()
    {
        InitializeComponent();
    }
}