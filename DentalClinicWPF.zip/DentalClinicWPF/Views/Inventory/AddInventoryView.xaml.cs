﻿using System.Windows;

namespace DentalClinicWPF.Views.Inventory;

public partial class AddInventoryView : Window
{
    public AddInventoryView()
    {
        InitializeComponent();
    }
}