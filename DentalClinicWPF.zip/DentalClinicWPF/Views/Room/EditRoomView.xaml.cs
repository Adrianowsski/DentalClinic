﻿using System.Windows;

namespace DentalClinicWPF.Views.Room;

public partial class EditRoomView : Window
{
    public EditRoomView()
    {
        InitializeComponent();
    }
}