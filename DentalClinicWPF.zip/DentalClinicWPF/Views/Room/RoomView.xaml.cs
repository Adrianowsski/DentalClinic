﻿using System.Windows.Controls;

namespace DentalClinicWPF.Views.Room;

public partial class RoomView : UserControl
{
    public RoomView()
    {
        InitializeComponent();
    }
}