﻿using System.Windows;

namespace DentalClinicWPF.Views.Room;

public partial class AddRoomView : Window
{
    public AddRoomView()
    {
        InitializeComponent();
    }
}